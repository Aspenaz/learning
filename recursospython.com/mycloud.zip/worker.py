#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#       worker.py
#       
#       Copyright 2014 Recursos Python - www.recursospython.com
#       

from threading import Thread
from time import localtime, sleep, strftime, time
from os import listdir, mkdir
from os.path import getsize, exists, isdir, isfile

from config import Config
from ftpmgr import FTPError, FTPManager


try:
    raw_input
except NameError:
    raw_input = input


class Worker():
    
    def __init__(self):
        # Cargar archivo de configuración
        self.config = Config()
        
        # Datos FTP
        self.host = self.config.get_ftp("host")
        self.port = int(self.config.get_ftp("port"))
        self.username = self.config.get_ftp("username")
        self.password = self.config.get_ftp("password")
        self.ftp_path = self.config.get_ftp("path")
        if not self.ftp_path.endswith("/"):
            self.local_path += "/"
        
        # Datos locales
        self.local_path = self.config.get_general("path")
        if not self.local_path.endswith("/"):
            self.local_path += "/"
        
        # Carga el tiempo de actualización y lo convierte a minutos
        self._update_time = float(
            self.config.get_timing("update_time")) * 60
        
        # FTP
        self.ftp_manager = FTPManager()
        
        # ¿Está activada la auto-actualización?
        self._autoupdate_enabled = False
        self._thread_can_execute = True
    
    def _async_sleep(self, seconds, callback):
        """
        Espera los segundos especificados en segundo plano.
        Luego, llama a la función callback.
        """
        def _f():
            sleep(seconds)
            callback()
        t = Thread(target=_f)
        t.start()
    
    def _get_local_files(self):
        """
        Retorna una lista con los archivos ubicados en
        la carpeta configurada (generalmente mycloud/).
        """
        return [i for i in listdir(self.local_path) if not isdir(i)]
    
    def _list_diff(self, a, b):
        """
        Retorna items de @a no encontrados en @b.
        """
        ret = []
        for i in a: 
            if i not in b:
                ret.append(i)
        return ret
    
    def _time_by_seconds(self, seconds):
        """
        Retorna una fecha legible a partir de los segundos.
        """
        return strftime("%a %d/%m (%H:%M)", localtime(seconds))
    
    def autoupdate(self):
        """
        Activa la auto-actualización.
        """
        if not self._autoupdate_enabled:
            print("Auto-actualizar activado.")
            self.update()
            self._autoupdate_enabled = True
            self.thread_init()
        else:
            print("Auto-actualizar desactivado.")
            self._autoupdate_enabled = False
            self.thread_exit()
    
    def update(self, loop=True, command=False, upload_all=False,
               download_all=False):
        """
        Realiza la conexión y autenticación.
        Sube y descarga los archivos necesarios.
        Cierra la conexión.
        """
        # Todas las funciones lanzan FTPError en caso
        # de fallar.
        try:
            # ¿La auto-actualización ya fue desactivada?
            if not command and not self._thread_can_execute:
                return
            
            # Crear la carpeta local
            if not exists(self.local_path):
                mkdir(self.local_path)
            
            # Conectar
            self.ftp_manager.connect(self.host, self.port)
            
            # Ingresar usuario y clave
            self.ftp_manager.authenticate(self.username, self.password)
            
            # Seleccionar los archivos de la carpeta local
            local_files = self._get_local_files()
            
            # Cambiar el directorio FTP
            self.ftp_manager.set_dir(self.ftp_path)
            
            # Obtener los archivos en la carpeta especificada
            ftp_files = self.ftp_manager.get_cwd_files()
            
            # Buscar archivos nuevos
            if not upload_all and not download_all:
                new_local_files = self._list_diff(local_files,
                                                  ftp_files)
                new_ftp_files = self._list_diff(ftp_files, local_files)
                
                print("%d archivos para cargar." % len(new_local_files))
                print("%d archivos para descargar." %
                      len(new_ftp_files))
                
                # Subir al FTP
                for local_file in new_local_files:
                    self.ftp_manager.upload(local_file, self.local_path)
                
                # Descargar desde el FTP
                for ftp_file in new_ftp_files:
                    self.ftp_manager.download(ftp_file, self.local_path)
                    local_files.append(ftp_file)
                
                # Subir archivos modificados
                for filename in local_files:
                    if (getsize(self.local_path + filename) !=
                        self.ftp_manager.size(filename)):
                        print("Archivo modificado: %s." % filename)
                        self.ftp_manager.upload(filename,
                                                self.local_path)
            else:
                if upload_all:
                    # Subir todo
                    for local_file in local_files:
                        self.ftp_manager.upload(local_file,
                                                self.local_path)
                elif download_all:
                    # Descargar todo
                    for ftp_file in ftp_files:
                        self.ftp_manager.download(ftp_file,
                                                  self.local_path)
            
            # Cerrar la conexión
            self.ftp_manager.close()
            
            # Establecer la última actualización
            self.config.set("timing", "last_update", str(time()))
            
            # Continuar con la ejecución de raw_input()
            if self._autoupdate_enabled and not command:
                print("#> ")
            
            # ¿Ejecutar nuevamente?
            if loop:
                self._async_sleep(self._update_time, self.update)
        except FTPError:
            # Ocurrió un error
            print("No se ha podido concretar. "
                  "Vuelva a intentarlo.")
            # Cerrar la conexión
            self.ftp_manager.close()
    
    def get_last_update(self):
        """
        Retorna hora y fecha de la última actualización.
        """
        last_update = self.config.get_timing("last_update")
        if not last_update:
            # Aún no se ha establecido el valor
            print("No hay registros.")
        else:
            # Convertir de segundos al nuevo formato
            print(self._time_by_seconds(float(last_update)))
    
    def get_next_update(self):
        """
        Retorna hora y fecha de la próxima actualización.
        """
        if self._autoupdate_enabled:
            print(self._time_by_seconds(time() + self._update_time))
        else:
            print("No ha habilitado el auto-actualizar.")
    
    def thread_init(self):
        """
        Comienza con la ejecución del hilo.
        """
        self._thread_can_execute = True
    
    def thread_exit(self):
        """
        Termina con la ejecuión del hilo.
        """
        self._thread_can_execute = False
    
    def run(self):
        """
        Inicializa realizando la primera actualización.
        """
        self.update()
