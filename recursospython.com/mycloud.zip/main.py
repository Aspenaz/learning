#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#       main.py
#       
#       Copyright 2014 Recursos Python - www.recursospython.com
#       

from sys import version_info, stdout

from cmdmgr import CommandManager
from config import Config
from worker import Worker

# Compatibilidad Python 3
try:
    raw_input
except NameError:
    raw_input = input

try:
    str = unicode
except NameError:
    pass


def require_input(prompt, default=False, numeric=False):
    """
    Solicita el ingreso de datos. Si default es especificado,
    su valor será utilizado si el usuario no ingresa ninguno.
    De lo contrario, se solicitará la entrada hasta que se ingrese
    un valor válido.
    """
    i = ""
    while not i:
        i = raw_input(
            prompt + (" (default: %s): " % default if default else ": ")
        )
        i = i or default
        if numeric:
            try:
                i = int(i)
            except ValueError:
                print("Debe ingresar un valor numerico.")
                i = ""
    return i


def main():
    """
    Función principal.
    Solicita el ingreso de datos de configuración de ser necesario.
    Lanza el hilo encargado de la actualización del contenido.
    """
    print("Bienvenido a MyCloud.\n")
    
    # Cargar el archivo de configuración
    try:
        config = Config()
    except IOError:
        print("Error: no se ha encontrado mycloud.ini.")
        return
    
    # Árbol de configuración
    cfg_values = (
        (
            # Nombre de la sección
            "general",
            # Descripción
            "Datos generales",
            (
                # Items (nombre, descripción, valor por defecto, numérico)
                ("path", "Ruta (Local)", "mycloud/", False),
            ),
        ),
        (
            "ftp",
            "Servidor FTP",
            (
                ("host", "Host", False, False),
                ("port", "Puerto", 21, True),
                ("username", "Usuario", "anonymous", False),
                ("password", "Clave", "anonymous@", False),
                ("path", "Ruta (FTP)", "mycloud/", False)
            ),
        ),
        (
            "timing",
            "Tiempo",
            (
                ("update_time", "Auto-Actualizar (minutos)", 10, True),
            )
        )
    )
    
    # Datos configurados en mycloud.ini
    for section in cfg_values:
        # Secciones (general, ftp, timing)
        section_name, section_prompt, items = section
        print(section_prompt)  # Descripción de la sección
        for item in items:
            # Tabulación para mayor prolijidad
            stdout.write("\t")
            item_name, item_prompt, default, numeric = item
            # Leer el valor del archivo
            value = config.get(section_name, item_name)
            if not value:
                # Almacenar un valor
                value = require_input(item_prompt, default, numeric)
                config.set(section_name, item_name, value)
            else:
                # Imprimir el valor guardado
                value = config.get(section_name, item_name)
                # Reemplazar la contraseña por asteriscos
                if item_name == "password":
                    value = "*" * len(value)
                print("%s: %s" % (item_prompt, value) + 
                      (" (default)" if value == str(default) else ""))
        print("")
    
    raw_input("Presione enter para continuar.")
    print("")
    
    # Clase prinicpal
    worker = Worker()
    
    # Intérprete de comandos
    command_manager = CommandManager(worker)
    command_manager.run()


if __name__ == "__main__":
    main()
