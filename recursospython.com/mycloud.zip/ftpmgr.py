#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#       ftpmgr.py (FTP Manager)
#       
#       Copyright 2014 Recursos Python - www.recursospython.com
#       

from ftplib import FTP, error_perm
from socket import gaierror
from sys import stdout
from time import mktime, strptime


try:
    raw_input
except NameError:
    raw_input = input


class FTPError(Exception):
    pass


class FTPManager(FTP):
    """
    Funciones varias para el manejo del servidor FTP.
    """
    
    def authenticate(self, username, password):
        """
        Ingresa con los datos especificados.
        """
        stdout.write("Ingresando (Usuario: %s, Clave: %s)... " %
                     (username, "*" * len(username)))
        try:
            self.login(username, password)
        except error_perm as e:
            print("Error (%s)." % e)
            raise FTPError
        else:
            print("Ha ingresado.")
    
    def connect(self, host, port):
        """
        Conecta con los datos especificados.
        """
        stdout.write("Conectando a %s:%d... " % (host, port))
        try:
            FTP.connect(self, host, port)
        except gaierror as e:
            print("Error: (%s)." % e)
            raise FTPError
        else:
            print("Conectado.")
    
    def close(self):
        """
        Cierra la conexión.
        """
        stdout.write("Cerrando... ")
        FTP.close(self)
        print("Cerrado.")
    
    def create_dir(self, name):
        """
        Crea un nuevo directorio en el servidor FTP.
        """
        stdout.write("Creando carpeta %s... " % name)
        try:
            self.mkd(name)
        except error_perm as e:
            print("Error (%s)." % e)
            raise FTPError
        else:
            print("Creada.")
    
    def get_cwd_files(self):
        """
        Retorna los archivos del directorio actual.
        """
        ret = None
        stdout.write("Obteniendo archivos... ")
        try:
            # Filtrar nombres "." y ".."
            ret = [i for i in self.nlst() if i != "." and i != ".."]
        except error_perm as e:
            print("Error (%s)." % e)
            raise FTPError
        else:
            print("Listo.")
        finally:
            return ret
    
    def set_dir(self, name):
        """
        Cambia la ubicación actual a @name.
        """
        stdout.write("Cambiando directorio a %s... " % name)
        try:
            self.cwd(name)
        except error_perm as e:
            e = str(e)
            print("Error (%s)." % e)
            # 550: No se ha encontrado el archivo especificado
            if e.startswith("550"):
                # Crear directorio
                self.create_dir(name)
        else:
            print("Listo.")
    
    def disable_input(self):
        """
        Desactiva la llamada a raw_input() desde esta clase.
        """
        self._input_enabled = False
    
    def download(self, filename, path):
        """
        Descargar un archivo desde el servidor FTP.
        """
        stdout.write("Descargando %s... " % filename)
        cmd = "RETR " + filename
        with open(path + filename, "wb") as f:
            self.retrbinary(cmd, f.write)
        print("Listo.")
    
    def upload(self, filename, path):
        """
        Cargar un archivo al servidor FTP.
        """
        stdout.write("Subiendo %s... " % filename)
        with open(path + filename, "rb") as f:
            self.storbinary("STOR " + filename, f)
        print("Listo.")
