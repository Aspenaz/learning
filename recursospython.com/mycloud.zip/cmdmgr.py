#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#       cmdmgr.py (Command manager)
#       
#       Copyright 2014 Recursos Python - www.recursospython.com
#       


try:
    raw_input
except NameError:
    raw_input = input


class CommandManager:
    
    def __init__(self, worker):
        self._worker = worker
        self._run = True
    
    def _exit(self):
        """
        Termina el hilo y finaliza el programa.
        """
        print("\nHasta luego.\n")
        self._worker.thread_exit()
        self._run = False
    
    def _execute_command(self, command):
        """
        Interpreta los comandos.
        """
        # Sin distinción mayúsculas / minúsculas
        command = command.lower()
        
        # Desplegar el menú de ayuda
        if command == "ayuda" or command == "0":
            self._show_help()
        # Actualizar inmediatamente
        elif command == "actualizar" or command == "1":
            self._worker.update(False, True)
        # Subir todos los archivos
        elif command == "subir_todo" or command == "2":
            self._worker.update(False, upload_all=True)
        # Descargar todos los archivos
        elif command == "bajar_todo" or command == "3":
            self._worker.update(False, download_all=True)
        # Actualizar automáticamente
        elif command == "auto_actualizar" or command == "4":
            self._worker.autoupdate()
        # Imprimir fecha y hora de la última actualización
        elif command == "ultima_actualizacion" or command == "5":
            self._worker.get_last_update()
        # Imprimir fecha y hora de la próxima actualización
        elif command == "proxima_actualizacion" or command == "6":
            self._worker.get_next_update()
        # Terminar el hilo y finalizar el programa
        elif command == "salir" or command == "7":
            self._exit()
        else:
            print("Comando no reconocido.")
    
    def _show_help(self):
        with open("menu", "r") as f:
            print(f.read())
    
    def run(self):
        print("\nIngrese un comando o 'ayuda' para ver una lista "
              "completa.")
        
        while self._run:
            try:
                # Entrada del usuario
                command = raw_input("#> ")
            except KeyboardInterrupt:
                # Terminar la ejecución
                self._exit()
            else:
                # Ejecutar el comando
                self._execute_command(command)
