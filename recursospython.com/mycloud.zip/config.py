#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#       config.py
#       
#       Copyright 2014 Recursos Python - www.recursospython.com
#       

# Compatibilidad Python 3
try:
    from ConfigParser import SafeConfigParser
except ImportError:
    from configparser import SafeConfigParser


try:
    str = unicode
except NameError:
    pass


class Config:
    
    def __init__(self):
        """
        Initializes the config parser. If the mycloud.ini file
        doesn't exists, IOError will be raised.
        """
        self.cfg = SafeConfigParser()
        if not self.cfg.read("mycloud.ini"):
            raise IOError
    
    def get(self, section, item):
        return self.cfg.get(section, item)
    
    def get_general(self, item):
        return self.get("general", item)
    
    def get_ftp(self, item):
        return self.get("ftp", item)
    
    def get_timing(self, item):
        return self.get("timing", item)
    
    def set(self, section, item, value):
        # Convertir valores numéricos y guardar los cambios
        ret = self.cfg.set(section, item, str(value))
        self._save_changes()
        
        return ret
    
    def _save_changes(self):
        with open("mycloud.ini", "w") as f:
            self.cfg.write(f)
    
    def get_ftp_values(self):
        """Returns all FTP values from the config file"""
        return (self.get_ftp("host"), self.get_ftp("port"),
                self.get_ftp("username"), self.get_ftp("password"),
                self.get_ftp("path"))
