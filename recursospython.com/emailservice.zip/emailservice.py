#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
    REST API example using Twisted Klein.
    Copyright (C) 2018 Recursos Python - reucrsospython.com.
"""

from email.mime.text import MIMEText
import json

from klein import Klein
from twisted.enterprise.adbapi import ConnectionPool
from twisted.internet.defer import inlineCallbacks
from twisted.mail.smtp import sendmail
from werkzeug.exceptions import NotFound, MethodNotAllowed


EMAIL_SERVER = ''
USER = ''
PASSWORD = ''


def emails_to_json(rows):
    def row_to_json(row):
        return json.dumps(
            {'id': row[0], 'to': row[1], 'sent': bool(row[2])})
    return tuple(map(row_to_json, rows))


class EmailService:
    app = Klein()
    cache = {}
    conn = ConnectionPool('sqlite3', 'emailservice.db')
    
    def query(self, *args):
        """Run a query using the current connection."""
        return self.conn.runQuery(*args)
    
    def response(self, request, succeed=True, status=200, **kwargs):
        """
        Build the response body as JSON and set the proper content-type
        header.
        """
        request.setHeader('Content-Type', 'application/json')
        request.setResponseCode(status)
        return json.dumps(
            {'succeed': succeed, 'status': status, **kwargs})
    
    def emailSent(self, result, emailID):
        """Called once the email was sent."""
        emails_sent = result[0]
        if emails_sent == 0:
            return
        self.query('UPDATE emails SET sent=1 WHERE id=?', (emailID,))
    
    def insertEmail(self, transaction, to):
        """
        This function gets called by Twisted in a thread so we can
        safely use blocking functions such as execute(). The return
        value is then retrieved to the main thread where
        runInteraction() was called.
        """
        transaction.execute(
            'INSERT INTO emails (recipient, sent) VALUES (?, ?);',
            (to, False)
        )
        return transaction.lastrowid
    
    @app.handle_errors(NotFound)
    def notFoundHandler(self, request, failure):
        """
        Called when a 404 not found is raised.
        """
        return self.response(
            request, succeed=False, status=404, reason='Not found.')
    
    @app.handle_errors(MethodNotAllowed)
    def methodNotAllowedHandler(self, request, failure):
        """
        Called when a 405 is raised.
        """
        return self.response(
            request, succeed=False, status=405, reason="Method not allowed.")
    
    @app.route('/email', methods=['GET', 'POST'],
               defaults={'emailID': None})
    @app.route('/email/<int:emailID>', methods=['GET'])
    @inlineCallbacks
    def email(self, request, emailID):
        if request.method == b'POST':
            # Look for missing params.
            for param in (b'to', b'message', b'subject'):
                if param not in request.args:
                    return self.response(
                        request,
                        succeed=False,
                        status=400,
                        reason="Missing parameter: '{}'.".format(
                            param.decode('utf-8'))
                    )
            to = request.args[b'to'][0].decode('utf-8')
            # Run the insert query and return the inserted ID.
            lastID = yield self.conn.runInteraction(self.insertEmail, to)
            message = MIMEText(
                request.args[b'message'][0].decode("utf-8"))
            message['Subject'] = \
                request.args[b'subject'][0].decode("utf-8")
            message['From'] = USER
            message['To'] = to
            d = sendmail(
                EMAIL_SERVER, USER, [to], message,
                username=USER, password=PASSWORD
            )
            d.addCallback(self.emailSent, lastID)
            return self.response(request, emailID=lastID)
        
        elif request.method == b'GET':
            # Look for a cached result before hitting the database.
            key = 'emails' if emailID is None else 'email-{}'.format(emailID)
            try:
                return self.cache[key]
            except KeyError:
                pass
            if emailID is None:
                # Get the full emails list.
                emails = yield self.query(
                    'SELECT id, recipient, sent FROM emails;')
            else:
                # Get the specified email.
                emails = yield self.query(
                    'SELECT id, recipient, sent FROM emails WHERE id=?',
                    (emailID,)
                )
                if not emails:
                    raise NotFound
            emails = emails_to_json(emails)
            if emailID is not None:
                emails = emails[0]
            response = self.response(request, emails=emails)
            self.cache[key] = response
            return response


if __name__ == '__main__':
    emailservice = EmailService()
    emailservice.app.run('localhost', 7001)
