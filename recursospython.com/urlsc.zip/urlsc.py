#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#       Copyright 2016 Recursos Python - www.recursospython.com
#
#

from string import ascii_lowercase
from urllib.request import urlopen

from bs4 import BeautifulSoup
from hunspell import HunSpell


def chars_filter(s, valid_chars):
    return "".join(c for c in s if c in valid_chars)


def main():
    url = "http://recursospython.com/guias-y-manuales/por-que-existe-python-3/"
    
    # Obtener contenido de la página.
    with urlopen(url) as r:
        content = r.read()
    
    # Analizar el código HTML.
    soup = BeautifulSoup(content, "html.parser")
    # Etiqueta HTML de donde extraer el texto.
    root = soup.article
    
    # Remover código innecesario.
    for tag in root.find_all(["script", "style", "code", "pre"]):
        tag.decompose()
    
    # Extraer texto, remover saltos de línea y convertir 
    # a minúsculas para agilizar la búsqueda.
    text = root.get_text().replace("\n", " ").lower()
    # Remover caracteres innecesario (puntuación y demás).
    text = chars_filter(text, ascii_lowercase + "áéíóúñü ")
    
    # Crear el diccionario y agregar las palabras necesarias.
    dic = HunSpell("es_ANY.dic", "es_ANY.aff")
    dic.add("python")
    
    unknown_words = {}
    
    # Buscar palabras que no se encuentren en el diccionario.
    for word in text.split(" "):
        if word:
            # Ignorar letras sueltas.
            if len(word) > 1 and not dic.spell(word):
                if word in unknown_words:
                    unknown_words[word] += 1
                else:
                    unknown_words[word] = 1
    
    print(len(unknown_words), "palabras desconocidas.")
    
    # Ordenar alfabéticamente e imprimir sugerencias.
    for word in sorted(unknown_words):
        print("{} ({}).".format(word, unknown_words[word]))
        suggest = dic.suggest(word)
        if suggest:
            print("¿Quiso decir {}?".format(
                ", ".join(s.decode("utf-8") for s in suggest)))


if __name__ == "__main__":
    main()
