
True Type Font: Software Kit 7 version 1.0


EULA
-==-
The font Software Kit 7 is freeware.


DESCRIPTION
-=========-
Kit of software symbols. May be useful for software developers.

Files in software_kit_7.zip:
       	readme.txt     				this file;
        software_kit_7.ttf 			regular font;
	software_kit_7_screen.png		preview image.

Please visit http://www.styleseven.com/ for download our other products as freeware as shareware.
We will welcome any useful suggestions and comments, please send them to ms-7@styleseven.com


NOTE
-==-
Please place credit information and/or back link to http://www.styleseven.com/.
Feel free to submit your applications to http://www.catalogofsoftware.com/submit.php
See also collections of freeware arrows: http://www.styleseven.com/php/get_product.php?product=Arrow%207


AUTHOR
-====-
Sizenko Alexander
Style-7
http://www.styleseven.com
Created: January 12 2014