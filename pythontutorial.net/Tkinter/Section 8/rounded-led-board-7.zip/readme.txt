
True Type Font: Rounded LED Board-7 version 1.0


EULA
-==-
The font Rounded LED Board-7 is freeware for home using only.


DESCRIPTION
-=========-
This is original font created in style a LED (Light Emitting Diode) matrix. Latin code page is supported.

Files in rounded_led_board-7.zip:
       	readme.txt     					this file;
        rounded_led_board-7.ttf    			regular true type font;
	rounded_led_board-7_screen.png	preview 	image.

Please visit http://www.styleseven.com/ for download our other products as freeware as shareware.
We will welcome any useful suggestions and comments; please send them to ms-7@styleseven.com


FREEWARE USE (NOTES)
-==================-
Also you may: 
 * Use the font in freeware software (credit needed);
 * Use the font for your education process.


COMMERCIAL OR BUSINESS USE
-========================-
Please contact us ($24.95).
You may:
 * Include the font to your installation;
 * Use one license up to 100 computers in your office.


AUTHOR
-====-
Sizenko Alexander
Style-7
http://www.styleseven.com
Created: January 18 2013